import { Report } from "../types";

// Seed coordinates centered around a hypothetical urban city center
// Default reference coordinate: Lat: 37.7749, Lng: -122.4194
export const mockReports: Report[] = [
  {
    id: "rep-1",
    image: null,
    category: "Pothole",
    description: "Huge pothole in the middle of the street. It is causing cars to swerve dangerously.",
    severity: "High",
    urgency: "Urgent",
    department: "Public Works",
    risk: "Presents a high risk of tire damage and potential collisions due to sudden swerving.",
    summary: "A large pothole has opened up in the lane. Urgent repair is requested to prevent vehicular damage and traffic accidents.",
    location: {
      lat: 37.7758,
      lng: -122.4182,
      address: "150 Golden Gate Ave, Civic Center",
    },
    status: "In Progress",
    supportCount: 42,
    date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(), // 4 days ago
  },
  {
    id: "rep-2",
    image: null,
    category: "Garbage",
    description: "Large piles of trash bags and furniture dumped on the sidewalk near the playground.",
    severity: "Medium",
    urgency: "Normal",
    department: "Waste Management",
    risk: "Attracts pests, blocks public pedestrian pathways, and degrades neighborhood sanitation.",
    summary: "Illegal dumping on the sidewalk. Garbage collection is requested to restore neighborhood hygiene and pathway access.",
    location: {
      lat: 37.7725,
      lng: -122.4168,
      address: "420 Mission St, SOMA Area",
    },
    status: "Reported",
    supportCount: 18,
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
  },
  {
    id: "rep-3",
    image: null,
    category: "Broken Streetlight",
    description: "The street light in front of the convenience store is completely dark. The area is pitch black.",
    severity: "Medium",
    urgency: "Normal",
    department: "Street Lighting & Electricity",
    risk: "Reduced visibility increases risk of pedestrian slips and criminal activity at night.",
    summary: "Outage of street light fixture. Maintenance requested to restore street visibility and neighborhood safety.",
    location: {
      lat: 37.7765,
      lng: -122.4215,
      address: "590 Van Ness Ave, Downtown",
    },
    status: "Verified",
    supportCount: 29,
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
  },
  {
    id: "rep-4",
    image: null,
    category: "Water Leakage",
    description: "Water is bubbling up from the pavement under the sidewalk, wasting hundreds of gallons.",
    severity: "High",
    urgency: "Critical",
    department: "Water Supply & Sewerage",
    risk: "Soil erosion, potential street collapse, and massive water loss.",
    summary: "Underground main water line burst. Urgent containment and repair requested to prevent street undermining and flooding.",
    location: {
      lat: 37.7741,
      lng: -122.4201,
      address: "800 Market St, Financial District",
    },
    status: "Reported",
    supportCount: 56,
    date: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
  },
  {
    id: "rep-5",
    image: null,
    category: "Fallen Tree",
    description: "Large pine branch broke during high winds and is completely blocking the bike lane.",
    severity: "High",
    urgency: "Urgent",
    department: "Parks & Forestry",
    risk: "Forces cyclists into traffic, posing an immediate risk of accidents.",
    summary: "Fallen heavy tree limb blocking the dedicated cycle lane. Clearing and debris removal requested immediately.",
    location: {
      lat: 37.7712,
      lng: -122.4230,
      address: "1200 Valencia St, Mission District",
    },
    status: "Resolved",
    supportCount: 88,
    date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days ago
  },
];
